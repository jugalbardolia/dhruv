<?php
include '../DBconnection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>City Delight</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <script src="../js/bootstrap.min.js"></script>
</head>
<body>
  <div class="row">
    <?php include 'slidebar.php' ?>
    <section class="offset-2">
    <div class="container-fluid">
      <div class="row">
        <div class="col-3 text-bg-info border rounded m-4">
          <div class="row">
            <div class="col-2">
              <?php
                $query = "select * from login";
                $result = mysqli_query($con,$query);
                $row = mysqli_num_rows($result);
                echo "<h1>".$row."</h1>";
              ?>
            </div>
            <div class="col-10">
              <h1>Users</h1>
            </div>
          </div>
        </div>
        <div class="col-3 text-bg-info border rounded m-4">
          <div class="row">
            <div class="col-2">
              <?php
                $query = "select * from product";
                $result = mysqli_query($con,$query);
                $row = mysqli_num_rows($result);
                echo "<h1>".$row."</h1>";
              ?>
            </div>
            <div class="col-10">
              <h1>Product</h1>
            </div>
          </div>
        </div>
        <div class="col-3 text-bg-info border rounded m-4">
          <div class="row">
            <div class="col-2">
              <?php
                $query = "select * from login";
                $result = mysqli_query($con,$query);
                $row = mysqli_num_rows($result);
                echo "<h1>".$row."</h1>";
              ?>
            </div>
            <div class="col-10">
              <h1>Users</h1>
            </div>
          </div>
        </div>
        <div class="col-3 text-bg-info border rounded m-4">
          <div class="row">
            <div class="col-2">
              <?php
                $query = "select * from login";
                $result = mysqli_query($con,$query);
                $row = mysqli_num_rows($result);
                echo "<h1>".$row."</h1>";
              ?>
            </div>
            <div class="col-10">
              <h1>Users</h1>
            </div>
          </div>
        </div>
      </div>
    </div>
    </section>
  </div>
</body>
</html>