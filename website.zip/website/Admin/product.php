<?php
include '../DBconnection.php';
?>

<?php
include '../DBconnection.php';

if(isset($_POST['submit']))
{
    $pn = $_POST['pn'];
    $pp = $_POST['pp'];

    $filename = $_FILES['p_image']['name'];
    $basename = substr($filename,0,strripos($filename,'.'));
    $ext = substr($filename,strripos($filename,'.'));
    $tempname = $_FILES['p_image']['tmp_name'];
    $allowed_type = array('.png','.jpg');
    $size = $_FILES['p_image']['size'];

    if(in_array($ext,$allowed_type) && $size < 20000000)
    {
        $newfilename = md5($basename).rand(10,1000).time().$ext;

        if(file_exists('upload/'.$newfilename))
        {
            echo "<script> alert('File alredy exits') </script>";
        }
        else
        {
            move_uploaded_file($tempname,"upload/".$newfilename);
            echo "<script> alert('image uploaded.') </script>";
        }
    }
    elseif($size >20000000)
    {
        echo "<script> alert('file is to large') </script>";
    }
    else{
        echo "<script> slert('Allowed file type are : '".implode(",",$allowed_type);
    }

    $query = "insert into product values(null,'$pn',$pp,'$newfilename')";
    $insert = mysqli_query($con,$query);
    if($insert==1)
    {
        echo "<script>alert('Inserted');</script>";
    }
    else{
        header('addProduct.php');
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>City Delight</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <script src="../js/bootstrap.min.js"></script>
</head>

<body>
    <div class="row">
        <?php include 'slidebar.php' ?>
        <section class="offset-2">
            <div class="container-fluid">
                <div class="d-grid gap-2 w-25">
                    <button type="button" id="addp" class="btn btn-success w-25" data-bs-toggle="modal" name="addp"
                        data-bs-target="#staticBackdrop">
                        Add Product
                    </button>
                </div>

                <div>
                    <div class="table-responsive w-50 m-3 border rounded">
                        <table class="table" style="background-color: bisque;">
                            <thead>
                                <tr>
                                    <th scope="col">Product ID</th>
                                    <th scope="col">Product Name</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Product Image</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "select * from product";
                                $result = mysqli_query($con, $query);
                                while ($row = mysqli_fetch_row($result)) {
                                    ?>

                                    <tr class="">
                                        <td scope="row">
                                            <?php echo $row[0]; ?>
                                        </td>
                                        <td>
                                            <?php echo $row[1]; ?>
                                        </td>
                                        <td>
                                            <?php echo $row[2]; ?>
                                        </td>
                                        <td><img src="<?php echo "./upload/" . $row[3] ?>" height="100px" width="100px ">
                                        </td>
                                    </tr>
                                    <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">Add Product</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" style="background-color: bisque;">
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="table-responsive-sm m-5">
                            <table class="table">
                                <tbody>
                                    <tr class="">
                                        <td scope="row"><label className="form-label">Product Name :
                                            </label></td>
                                        <td><input type="text" class="form-control inp" name="pn" id='tt' />
                                        </td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row"><label className="form-label">Price : </label></td>
                                        <td><input type="text" class="form-control inp" name="pp" /></td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row"><label className="form-label">Product Image :
                                            </label></td>
                                        <td><input type="file" class="form-control inp" name="p_image" />
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    
                </div>
                <div class="modal-footer">
                    <input type="submit" value="Add" class="btn btn-success ms-5 w-25" name="submit">
                    <input type="reset" value="Reset" class="btn btn-secondary ms-5">
                </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>