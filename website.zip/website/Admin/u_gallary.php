<?php

include '../DBconnection.php';
$img_path = "";
if (isset($_GET['action'])) {
    if ($_GET['action'] == 'update') {
        $ID = $_GET['id'];
        $query = "select * from image where img_id=$ID";

        $result = mysqli_query($con, $query);
        while ($row = mysqli_fetch_array($result)) {
            $img_path = $row['img_path'];
        }
    }
}

if (isset($_POST['i_update'])) {
    $filename = $_FILES['p_image']['name'];
    $basename = substr($filename, 0, strripos($filename, '.'));
    $ext = substr($filename, strripos($filename, '.'));
    $tempname = $_FILES['p_image']['tmp_name'];
    $allowed_type = array('.png', '.jpg');
    $size = $_FILES['p_image']['size'];

    if (in_array($ext, $allowed_type) && $size < 20000000) {
        $newfilename = md5($basename) . rand(10, 1000) . time() . $ext;

        if (file_exists('upload/' . $newfilename)) {
            echo "<script> alert('File alredy exits') </script>";
        } else {
            move_uploaded_file($tempname, "g_upload/" . $newfilename);
            echo "<script> alert('image uploaded.') </script>";
        }
    } elseif ($size > 20000000) {
        echo "<script> alert('file is to large') </script>";
    } else {
        echo "<script> slert('Allowed file type are : '" . implode(",", $allowed_type);
    }

    $query = "update image set img_path='$newfilename' where img_id=$ID";
    $insert = mysqli_query($con, $query);
    if ($insert == 1) {
        echo "<script>alert('Updated..!!!');</script>";
    } else {
        header('addProduct.php');
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>City Delight</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <script src="../js/bootstrap.min.js"></script>
</head>

<body>
    <div class="row">
        <?php include 'slidebar.php' ?>
        <section class="offset-2">
            <div class="container-fluid">
                <h1 class="ms-5">Update Image</h1>
                <form action="" method="post" enctype="multipart/form-data" class="w-50">
                    <table class="table" style="background-color: bisque;">
                        <tbody>
                            <tr class="">
                                <td scope="row"><label className="form-label">Image :
                                    </label></td>
                                <td><input type="file" class="form-control w-50" name="p_image" />
                                </td>
                                <td><img src="<?php echo "./g_upload/" . $img_path ?>" height="100px" width="100px ">
                                </td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="3"><input type="submit" value="Update" class="btn btn-success ms-5 w-25"
                                        name="i_update">
                                    <input type="reset" value="Reset" class="btn btn-secondary ms-5">
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </form>
            </div>
    </div>
    </div>
    </section>
    </div>
</body>

</html>