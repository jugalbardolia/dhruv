<?php
$con = mysqli_connect("localhost","root","dcs123","dairy_product");
?>