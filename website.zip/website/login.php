<?php
include 'DBconnection.php';
session_start();
if(isset($_POST['login']))
{
    $mail= $_POST['txtemail'];
    $pass = $_POST['txtpass'];
    $flag=0;
    $query = "select * from login where email='$mail' and password='$pass'";
                $resul= mysqli_query($con,$query);
    
                if(mysqli_fetch_array($resul)>0)
                {
                    $flag=1;

                    // header("location: ./user/index.php");
                }
                else{
                    echo "<script>alert('Wrong email and passwprd');</script>";
                    header("location: login.php");
                }
                $query1 = "select * from admin where username='$mail' and password='$pass'";
                $resul= mysqli_query($con,$query1);
    
                if(mysqli_fetch_array($resul)>0)
                {
                    $flag=0;
                    
                }
                else{
                    echo "<script>alert('Wrong email and passwprd');</script>";
                    // header("location: login.php");
                }

                if($flag==0)
                {
                    header("location: ./Admin/index.php");
                }else if($flag==1){
                    $_SESSION['txtemail'] = $mail;
                    header("location: ./user/index.php");
                }
                else{
                    header("Location: login.php");
                }
}
// session_start();
// if(isset($_POST['RememberMe']))
// {
//     setcookie('email',$_POST['txtemail'],time()+3600);
//     setcookie('password',$_POST['txtpass'],time()+3600);
// }
// if(isset($_POST['login']))
// {
//     $mail= $_POST['txtemail'];
//     $pass = $_POST['txtpass'];
//     if(isset($_COOKIE))
//     {
//         if(strcmp($mail,$_COOKIE['email'])==0 && strcmp($pass,$_COOKIE['password'])==0)
//         {
//             $_SESSION['txtemail'] = $mail;
//             header("location: ./user/index.php");
//         }
//         else{
//             $query = "select * from login where email='$mail' and password='$pass'";
//             $resul= mysqli_query($con,$query);

//             if(mysqli_fetch_array($resul)>0)
//             {
//                 header("location: ./user/index.php");
//             }
//             else{
//                 echo "<script>alert('Wrong email and passwprd');</script>";
//                 header("location: login.php");
//             }
//         }
//     }
    
// }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>citydelight</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css1/login.css">
    <script>
        
    </script>
</head>

<body>
    <div class="container-fulid" >
        <div class="row" style="height: 700px; width: 1300px; border-radius: 3px; margin-top: 100px; margin-left: 200px; background-color: bisque;">
            <div class="col-6">
                <img src="./image/login.jpg" alt="" srcset="" height="600px" width="600px" style="margin-left: 40px; margin-top: 40px;">
            </div>
            <div class="col-6" style="margin-top: 150px;">
                <h1 style="margin-left: -100px;">Welcome back&nbsp;<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-emoji-smile-fill" viewBox="0 0 16 16">
                    <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zM7 6.5C7 7.328 6.552 8 6 8s-1-.672-1-1.5S5.448 5 6 5s1 .672 1 1.5zM4.285 9.567a.5.5 0 0 1 .683.183A3.498 3.498 0 0 0 8 11.5a3.498 3.498 0 0 0 3.032-1.75.5.5 0 1 1 .866.5A4.498 4.498 0 0 1 8 12.5a4.498 4.498 0 0 1-3.898-2.25.5.5 0 0 1 .183-.683zM10 8c-.552 0-1-.672-1-1.5S9.448 5 10 5s1 .672 1 1.5S10.552 8 10 8z"/>
                  </svg></h1>
                <form style="margin-top: 80px;" action="" method="post">
                    <div class="mb-3" style="margin-left: 140px;">
                        <input type="email" class="form-control w-50" name="txtemail"
                            placeholder="name@example.com" name="uid" >
                    </div>
                    <div class="mb-3" style="margin-left: 140px;">
                        <input type="password" class="form-control w-50" name="txtpass" 
                            placeholder="password" >
                    </div>
                    <div class="mb-3" style="margin-left: 140px;">
                        <input type="checkbox" name="RememberMe">
                        Remember me
                    </div>
                    <div style="margin-left: 140px; margin-top: 30px;">
                        <button type="submit" class="btn btn-warning w-25" name="login">Login</button>
                        <button type="reset" class="btn btn-secondary w-25" onclick="onreset()">Reset</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>