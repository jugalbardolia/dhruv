<?php
include './DBconnection.php';
include './navbar.php';

if (isset($_POST['p_id'])) {
    if(isset($_SESSION['txtemail']))
    {
        
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <div class="mt-4">
        <center>
            <h1>Dairy Product</h1>
        </center>
    </div>
    <div class="row ms-2 mt-5 me-3">
        <?php
        $query = "select * from product";
        $result = mysqli_query($con, $query);
        while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <div class="col-3 mt-4">
                <div class="card" style="width: 29rem; height:23rem">
                    <img src="Admin/upload/<?php echo $row['product_image']; ?>" class="card-img-top" alt="..."
                        height="170px" width="100px">
                    <div class="card-body" style="background-color: bisque;">
                        <form method="post" action="">
                            <input type="hidden" name="p_id" value="<?=$row['pid']?>">
                            <h3 class="card-text">
                                <?php echo $row['product_name']; ?>
                            </h3>
                            <h2 class="card-text">Rs.
                                <?php echo $row['price']; ?>
                            </h2><br />
                            <center><a class="btn btn-primary w-50" href="" style="height: 40px;">Add to Cart</a></center>
                        </form>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
    <?php include './Footer.php' ?>
</body>

</html>