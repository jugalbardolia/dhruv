<?php
include '../DBconnection.php';
include './u_navbar.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css1/index.css">
    <script src="../js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container-fluid">
        <h1 style="text-align: center;">Blog</h1>
        <div class="row">
            <div class="col-6">
                <?php
                $query = "select * from blog";
                $result = mysqli_query($con, $query);
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>

                    <div class="col-md-6">
                        <div
                            class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                            <div class="col p-4 d-flex flex-column position-static">
                                <h3 class="mb-0"><?= $row['blog_title']?></h3>
                                <div class="mb-1 text-body-secondary">Nov 12</div>
                                <p class="card-text mb-auto"><?=$row['blog_desc']?></p>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
            <div style="border: 2px solid black;" class="col-6rounded">
                <form style="margin-top: 20px;" action="" method="post" class="mb-4">
                    <div class="mb-3" style="margin-left: 140px;">
                        <input type="text" class="form-control w-50" name="txtblog" placeholder="name@example.com">
                    </div>
                    <div class="mb-3" style="margin-left: 140px;">
                        <textarea class="form-control w-50" name="txtdesc" placeholder="Description"></textarea>
                    </div>
                    <div class="mb-3" style="margin-left: 140px;">
                        <input type="date" name="cdate" class="form-control w-50" readonly>
                    </div>
                    <div style="margin-left: 140px; margin-top: 30px;">
                        <button type="submit" class="btn btn-warning w-25" name="login">Login</button>
                        <button type="reset" class="btn btn-secondary w-25" onclick="onreset()">Reset</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>