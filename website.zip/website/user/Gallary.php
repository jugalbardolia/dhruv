<?php
include '../DBconnection.php';
include 'u_navbar.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <script src="./js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container-fluid">
        <h1 style="text-align: center;">Dairy Fram Image</h1>
        <div class="row">
            <?php
            $query = "select * from image";
            $result = mysqli_query($con,$query);
            while($row=mysqli_fetch_array($result))
            {
            ?>
            <div class="col-3"><img src="<?php echo "../Admin/g_upload/" . $row['img_path']; ?>" height="350px" width="450px " class="rounded m-2"></div>
            <?php
            }
            ?>
        </div>
    </div>
</body>
</html>