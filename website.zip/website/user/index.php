<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>citydelight</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css1/index.css">
  <script src="../js/bootstrap.min.js"></script>
</head>

<body>
  <!--navbar-->
  <?php include 'u_navbar.php'; ?>

  <!--Carasoul-->
  <div class="container-fluid">
    <div class="row mt-3" style="border-radius: 5px;">
      <div id="carouselExampleCaptions" class="carousel slide">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
            aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
            aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
            aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="./image/carasolu2.jpg" class="d-block w-100" alt="..." height="650px">
            <div class="carousel-caption d-none d-md-block"
              style="margin-bottom: 70px; text-align: center; background-color: bisque; color: black; border-radius: 5px;">
              <h5> Welcome TO city Delight</h5>
              <p>We provide dairy product which is good & best for all.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="./image/carasolu3.jpg" class="d-block w-100" alt="..." height="650px">
            <div class="carousel-caption d-none d-md-block"
              style="margin-bottom: 70px; text-align: center; background-color: bisque; color: black; border-radius: 5px;">
              <h5> Welcome TO city Delight</h5>
              <p>We provide dairy product which is good & best for all.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="./image/carasolu4.jpg" class="d-block w-100" alt="..." height="650px">
            <div class="carousel-caption d-none d-md-block"
              style="margin-bottom: 70px; text-align: center; background-color: bisque; color: black; border-radius: 5px;">
              <h5> Welcome TO city Delight</h5>
              <p>We provide dairy product which is good & best for all.</p>
            </div>
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
          data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
          data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </div>
  </div>

  <!--product-->
  <div class="container-fluid">
    <div style="margin-top: 90px; text-align: center;">
      <h1>Prodcuts</h1>
    </div>
    <div class="row" style="margin-top: 40px;">
      <div class="col-3">
        <div class="card" style="width:28rem;">
          <img src="./image/dairy products/milk-can-.jpg" class="card-img-top" alt="..." height="320px">
          <div class="card-body" style="text-align: center; background-color: bisque;">
            <h1 class="card-text">Milk</h1>
          </div>
        </div>
      </div>
      <div class="col-3">
        <div class="card" style="width: 28rem;">
          <img src="./image/product/butter.jpg" class="card-img-top" alt="..." height="320px">
          <div class="card-body" style="text-align: center; background-color: bisque;">
            <h1 class="card-text">Butter</h1>
          </div>
        </div>
      </div>
      <div class="col-3">
        <div class="card" style="width: 28rem;">
          <img src="./image/product/cheese.jpg" class="card-img-top" alt="..." height="320px">
          <div class="card-body" style="text-align: center; background-color: bisque;">
            <h1 class="card-text">Cheese</h1>
          </div>
        </div>
      </div>
      <div class="col-3">
        <div class="card" style="width: 28rem;">
          <img src="./image/product/lassi.jpg" class="card-img-top" alt="..." height="320px">
          <div class="card-body" style="text-align: center; background-color: bisque;">
            <h1 class="card-text">Lassi</h1>
          </div>
        </div>
      </div>
    </div>
    <div class="row" style="margin-top: 20px;">
      <div class="col-3">
        <div class="card" style="width: 28rem;">
          <img src="./image/product/shrikhand.jpg" class="card-img-top" alt="..." height="320px">
          <div class="card-body" style="text-align: center; background-color: bisque;">
            <h1 class="card-text">Shrikhand</h1>
          </div>
        </div>
      </div>
      <div class="col-3">
        <div class="card" style="width:28rem;">
          <img src="./image/product/butter-milk.jpg" class="card-img-top" alt="..." height="320px">
          <div class="card-body" style="text-align: center; background-color: bisque;">
            <h1 class="card-text">Butter Milk</h1>
          </div>
        </div>
      </div>
      <div class="col-3">
        <div class="card" style="width: 28rem;">
          <img src="./image/product/tofu.jpg" class="card-img-top" alt="..." height="320px">
          <div class="card-body" style="text-align: center; background-color: bisque;">
            <h1 class="card-text">Tofu</h1>
          </div>
        </div>
      </div>
      <div class="col-3">
        <div class="card" style="width: 28rem;">
          <img src="./image/dairy products/yogurt.jpg"   class="card-img-top" alt="..." height="320px">
          <div class="card-body" style="text-align: center; background-color: bisque;">
            <h1 class="card-text">Yogurt</h1>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!--Dairy Product-->
  <div class="container-fluid">
    <div style="text-align: center; margin-top: 90px;">
      <h1>Dairy Product</h1>
    </div>
    <div style="margin-top: 40px;">
      <div id="carouselExampleIndicators" class="carousel slide">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active"
            aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1"
            aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2"
            aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <div class="row">
              <div class="col-2">
                <div class="card" style="width: 17rem; margin-left: 20px;">
                  <img src="./image/dairy products/kesar-lassi.jpg" class="card-img-top" alt="..." height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">Kesar Lassi</h5>
                    <h5 class="card-text">Rs. 80</h5>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="card" style="width: 17rem;">
                  <img src="./image/dairy products/butter.jpg" class="card-img-top" alt="..." height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">Butter 500g</h5>
                    <h5 class="card-text">100 rs.</h5>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="card" style="width: 17rem;">
                  <img src="./image/dairy products/butter-milke.jpg" class="card-img-top" alt="..."height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">Butter milke</h5>
                    <h5 class="card-text">50 rs.</h5>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="card" style="width: 17rem;">
                  <img src="./image/dairy products/milk-can-.jpg" class="card-img-top" alt="..." height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">Milke</h5>
                    <h5 class="card-text">30 rs.</h5>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="card" style="width: 17rem;">
                  <img src="./image/dairy products/white-cheese.jpg" class="card-img-top" alt="..." height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">White Cheese 500g</h5>
                    <h5 class="card-text">450 rs.</h5>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="card" style="width: 17rem;">
                  <img src="./image/dairy products/strawberry.jpg" class="card-img-top" alt="..." height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">Strawberry Shrikhand 500g</h5>
                    <h5 class="card-text">250 rs.</h5>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="row">
              <div class="col-2">
                <div class="card" style="width: 17rem; margin-left: 20px;">
                  <img src="./image/dairy products/mavaladdu.jpg" class="card-img-top" alt="..." height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">Mava Laddu 250g</h5>
                    <h5 class="card-text">Rs. 80</h5>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="card" style="width: 17rem;">
                  <img src="./image/dairy products/tofu.jpg" class="card-img-top" alt="..." height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">Tofu 500g</h5>
                    <h5 class="card-text">100 rs.</h5>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="card" style="width: 17rem;">
                  <img src="./image/dairy products/buuter-qube.jpg" class="card-img-top" alt="..."height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">Butter Qube</h5>
                    <h5 class="card-text">20 rs.</h5>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="card" style="width: 17rem;">
                  <img src="./image/dairy products/almon-shrikhand.jpg" class="card-img-top" alt="..." height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">Almon Shrikhand</h5>
                    <h5 class="card-text">130 rs.</h5>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="card" style="width: 17rem;">
                  <img src="./image/dairy products/raspberries yogurt.jpg" class="card-img-top" alt="..." height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">Rasprbriies Yogurt</h5>
                    <h5 class="card-text">250 rs.</h5>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="card" style="width: 17rem;">
                  <img src="./image/dairy products/white egg.jpg" class="card-img-top" alt="..." height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">White Egg</h5>
                    <h5 class="card-text">50 rs.</h5>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="row">
              <div class="col-2">
                <div class="card" style="width: 17rem; margin-left: 20px;">
                  <img src="./image/dairy products/mangolassi.jpg" class="card-img-top" alt="..." height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">Mango Lassi</h5>
                    <h5 class="card-text">Rs. 80</h5>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="card" style="width: 17rem;">
                  <img src="./image/dairy products/tofu slies.jpg" class="card-img-top" alt="..." height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">Tofu Slies</h5>
                    <h5 class="card-text">50 rs.</h5>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="card" style="width: 17rem;">
                  <img src="./image/dairy products/strawberry-3132973_1280.jpg" class="card-img-top" alt="..."height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">Strawberry Yogurt</h5>
                    <h5 class="card-text">350 rs.</h5>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="card" style="width: 17rem;">
                  <img src="./image/dairy products/brown egg.jpg" class="card-img-top" alt="..." height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">Brown Egg</h5>
                    <h5 class="card-text">30 rs.</h5>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="card" style="width: 17rem;">
                  <img src="./image/dairy products/chesee wheel.jpg" class="card-img-top" alt="..." height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">Cheese wheel 500g</h5>
                    <h5 class="card-text">450 rs.</h5>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="card" style="width: 17rem;">
                  <img src="./image/dairy products/yogurtbery.jpg" class="card-img-top" alt="..." height="150px" width="100px">
                  <div class="card-body" style="background-color: bisque;">
                    <h5 class="card-text">Yogurt berry</h5>
                    <h5 class="card-text">150 rs.</h5>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"
          data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"
          data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </div>
  </div>

  <!--About us-->
  <div class="container-fluid">
    <h1 style="margin-top: 90px; text-align: center;">About US</h1>
    <div class="row" style="background-color: bisque; height: 550px; margin-top: 40px;">
      <div class="col-6" style="margin: 40px;">
        <img src="./image/about.jpg" alt="" srcset="" height="500px" width="850px">
      </div>
      <div class="col-6" style="margin-left: -110px; margin-top: 150px;">
        <h3>HAVE MORE THAN 20 YEARS</h3>
        <P style="text-align: justify; font-size: larger;">City Delight is india's largest online dairy product delivery site.Begin a subscription-based e groceru site, Citydelight.com has already garnered the love of 20000+ happy customer across the suraty and valsad.Chosse from 1,0000+ products,enjoy a hassles-freee, convenient, easy shopping experinces.
        </P>
        <p style="text-align: justify; font-size: larger;">
        Do you generally forget to stock up on groceries & other dairy essentials? Or searching "milk delivery near me" on googles is keping you busy> If your aswer is 'YES', cityDelight.com is just the right site for you. Place your order, buy your milk online, & we take care of the rest</p>
      </div>
    </div>
  </div>

  <!-- Gallery -->
  <div class="container-fluid">
    <h1 style="text-align: center; margin-top: 100px;">Gallery</h1>
    <div class="row" style="margin-top: 50px;">
      <div class="col-3">
        <img src="../image/gallery/i1.jpg" alt="" srcset="" height="280px" width="450px" style="border-radius: 5px;">
      </div>
      <div class="col-3">
        <img src="../image/gallery/i2.jpg" alt="" srcset="" height="280px" width="450px"style="border-radius: 5px;">
      </div>
      <div class="col-3">
        <img src="../image/gallery/i3.jpg" alt="" srcset="" height="280px" width="450px" style="border-radius: 5px;">
      </div>
      <div class="col-3">
        <img src="../image/gallery/i4.jpg" alt="" srcset="" height="280px" width="450px" style="border-radius: 5px;">
      </div>
    </div>
    <div class="row" style="margin-top: 30px;">
      <div class="col-3">
        <img src="../image/gallery/i5.jpg" alt="" srcset="" height="280px" width="450px" style="border-radius: 5px;">
      </div>
      <div class="col-3">
        <img src="../image/gallery/i6.jpg" alt="" srcset="" height="280px" width="450px"style="border-radius: 5px;">
      </div>
      <div class="col-3">
        <img src="../image/gallery/i7.jpg" alt="" srcset="" height="280px" width="450px" style="border-radius: 5px;">
      </div>
      <div class="col-3">
        <img src="../image/gallery/i8.jpg" alt="" srcset="" height="280px" width="450px" style="border-radius: 5px;">
      </div>
    </div>
    <!-- <div class="row" style="margin-top: 30px;">
      <div class="col-3">
        <img src="./image/gallery/i9.jpg" alt="" srcset="" height="280px" width="450px" style="border-radius: 5px;">
      </div>
      <div class="col-3">
        <img src="./image/gallery/i10.jpg" alt="" srcset="" height="280px" width="450px"style="border-radius: 5px;">
      </div>
      <div class="col-3">
        <img src="./image/gallery/i11.jpg" alt="" srcset="" height="280px" width="450px" style="border-radius: 5px;">
      </div>
      <div class="col-3">
        <img src="./image/gallery/i2.jpg" alt="" srcset="" height="280px" width="450px" style="border-radius: 5px;">
      </div> -->
      <div style=" align-items: center; text-align: center; margin-top: 30px;">
        <a href="./user/Gallary.php" role="button" style="height: 50px; width: 190px; border-radius: 7px; background-color: bisque;">View More</a>
      </div>
    </div>
  </div>

  <!-- Contact -->
  <div class="container-fluid">
    <div style="margin-top: 100px; text-align: center;">
      <h1>Contact Us</h1>
    </div>
    <div class="row" style="background-color: bisque; height: 550px; margin-top: 40px;">
      <div class="col-6">
        <form style="margin-top: 150px; margin-left: 110px;">
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Email address</label>
            <input type="email" class="form-control w-50" id="exampleFormControlInput1" placeholder="name@example.com">
          </div>
          <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label">Comments </label>
            <textarea class="form-control w-50" id="exampleFormControlTextarea1" rows="3"></textarea>
          </div>
          <div class="mb-3 mt-5">
            <input type="submit" class="form-control w-25 btn btn-success" id="exampleFormControlInput1" value="Submit" >
            <input type="button" class="form-control w-25 btn btn-warning" id="exampleFormControlInput1" value="Reset">
          </div>
        </form>
      </div>
      <div class="col-6">
        <h3 style="margin-top: 100px; margin-left: 40px;">You can contact us or follow us for more inquiry on above pages :</h3>
        <h6 style="margin-top: 60px; margin-left: 40px;">
          <h5>Head office:</h5>
          <p>B-56 
            Sachin Industrial Complex<br/>
            Sachin,Surat<br/>Gujarat<br/>
            Ph - 0261-5623652
          </p>
        </h6>
        <h6 style="margin-top: 60px; margin-left: 40px;">
          <h5>Branch office:</h5>
          <p>123-borivali west , Mumbai</p>
        </h6>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <?php include './Footer.php' ?>
</body>

</html>