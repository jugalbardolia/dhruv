<?php 
session_start();
// echo "<script>alert('Do you want logout');</script>";
session_destroy();
// unset($_SESSION['txtemail']);
// echo "<script>alert('logout Successdully');
    // windows.location = '../index.html';</script>";

header("location:../index.html");
?>
