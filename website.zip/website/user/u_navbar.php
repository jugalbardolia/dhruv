<!-- <?php
session_start();
?> -->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>citydelight</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css1/index.css">
  <script src="../js/bootstrap.min.js"></script>
</head>

<body>
  <!--navbar-->
  <div class="container-fluid">
    <div class="row">
      <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid" style="background-color: blanchedalmond">
          <a class="navbar-brand" href="index.html"><img src="./image/logo.jpg" alt="" srcset=""
              style="height: 130px; width: 130px; border-radius: 2px;"></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
            aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link nav1" aria-current="page" href="./index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link nav1" href="./Product.php">Product</a>
              </li>
              <li class="nav-item">
                <a class="nav-link nav1" href="./Gallary.php">Gallery</a>
              </li>
              <li class="nav-item">
                <a class="nav-link nav1" href="./Blog.php">Blog</a>
              </li>
              <li class="nav-item">
                <a class="nav-link nav1" href="#">Contact us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link nav1" href="#">About us</a>
              </li>
              <li style="background-color: cadetblue; color: aliceblue; width: 150px;text-align: center;margin: 20px;padding: 10px;border-radius: 7px;   ">
                <?php echo $_SESSION['txtemail'] ?><a href="logout.php" style="margin-left:15px;">logout</a>
              </li>
              <li class="nav-item">
                <a class="nav-link nav1" href="#">Cart</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
  </div>
</body>
</html>